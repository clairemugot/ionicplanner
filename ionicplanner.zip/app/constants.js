define(['require'], function(require) {
    return {

        /**
         * Application constants. This values generated from all service settings.
         * Also there are Push Notification settings there if Push Notifications enabled for this project.
         */

        /**
         * Settings
         */
        Settings: {}
    };
});