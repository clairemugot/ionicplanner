x2js
====

x2js clone for the GIT world. 
Original sources, issue tracker and mercurial repository available at http://code.google.com/p/x2js
